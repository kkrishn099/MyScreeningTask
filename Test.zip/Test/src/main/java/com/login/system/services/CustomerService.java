package com.login.system.services;

import com.login.system.beans.Customer;

public interface CustomerService {

	public void saveCustomer(Customer customer);
}
